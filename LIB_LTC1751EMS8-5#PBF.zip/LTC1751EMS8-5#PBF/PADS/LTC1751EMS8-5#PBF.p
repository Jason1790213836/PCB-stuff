*PADS-LIBRARY-PART-TYPES-V9*

LTC1751EMS8-5#PBF SOP65P490X110-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.11.05.19.43.33
"Mouser Part Number" 584-LTC1751EMS8-5PBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/LTC1751EMS8-5PBF/?qs=hVkxg5c3xu%252BX6Q6vFq4XxA%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" LTC1751EMS8-5#PBF
"Description" Charge Pump STPUP 5V 100mA 8-Pin MSOP Tube
"Datasheet Link" https://www.arrow.com/en/products/ltc1751ems8-5pbf/analog-devices
"Geometry.Height" 1.1mm
GATE 1 8 0
LTC1751EMS8-5#PBF
1 0 U PGOOD
2 0 U VOUT
3 0 U VIN
4 0 U GND
8 0 U SS
7 0 U \SHDN
6 0 U C+
5 0 U C-

*END*
*REMARK* SamacSys ECAD Model
1394160/1798179/2.50/8/3/Integrated Circuit
